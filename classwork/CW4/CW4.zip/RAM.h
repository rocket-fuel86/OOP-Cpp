#pragma once

#include <iostream>
#include <string>
using namespace std;

class RAM
{
	string brand;
	int ddr;
	int speed;
	int memory;
public:
	RAM();
	RAM(string brand, int ddr, int speed);
	void setBrand(string brand);
	void setDdr(int ddr);
	void setSpeed(int speed);
	void setMemory(int memory);

	string getBrand();
	int getDdr();
	int getSpeed();
	int getMemory();

	void PrintInfo();
};

