#include "RAM.h"

RAM::RAM()
{

}

RAM::RAM(string brand, int ddr, int speed)
{
}

void RAM::setBrand(string brand)
{
}

void RAM::setDdr(int ddr)
{
}

void RAM::setSpeed(int speed)
{
}

void RAM::setMemory(int memory)
{
}

string RAM::getBrand()
{
	return string();
}

int RAM::getDdr()
{
	return 0;
}

int RAM::getSpeed()
{
	return 0;
}

int RAM::getMemory()
{
	return 0;
}

void RAM::PrintInfo()
{
}
